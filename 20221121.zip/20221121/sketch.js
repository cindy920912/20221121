var face_size=[]
var place_x=[]
var place_y=[]


function setup() {
    createCanvas(windowWidth, windowHeight);
    angleMode(DEGREES)
	 rectMode(CENTER)
var song
var songIsplay=false
var amp
function preload(){
  song = loadSound("Baby shark");
	}

  for (var i=0;i<5;i++){
    face_size[i] = random(0.5,5)
    place_x [i]= random(10,width)
    place_y [i]= random(10,height)
    }
  }
  function draw() {
    background("#DFE9FF"); //一開始的背景顏色 
    textSize(50)
    text("X:"+mouseX+"  Y:"+mouseY,50,50)
    for(var j=0;j<5;j++)
    {
    push()
    translate(place_x[j],place_y[j])
	//開始畫圖案
	
	fill("#F56861")  

fill(122, 143, 163);
// Shark body
			if(mouseIsPressed){
				strokeWeight(2)
				}
	
triangle(305/face_size[j]+face_size[j], 350/face_size[j]+face_size[j], 420/face_size[j]+face_size[j], 395/face_size[j]+face_size[j], 305/face_size[j]+face_size[j], 450/face_size[j]+face_size[j]);
strokeWeight(5);
ellipse(600/face_size[j]+face_size[j], 400/face_size[j]+face_size[j], 400/face_size[j]+face_size[j], 100/face_size[j]+face_size[j]);
strokeWeight(2);
noStroke(0)
triangle(305/face_size[j]+face_size[j], 350/face_size[j]+face_size[j], 420/face_size[j]+face_size[j], 395/face_size[j]+face_size[j], 305/face_size[j]+face_size[j], 450/face_size[j]+face_size[j]);
//Rounded rectangle corners with radii
rect(520/face_size[j]+face_size[j],330/face_size[j]+face_size[j],100/face_size[j]+face_size[j],30/face_size[j]+face_size[j], 28/face_size[j]+face_size[j]);
ellipseMode(CENTER)
fill(0);
ellipse (750/face_size[j]+face_size[j]+mouseX/200, 390/face_size[j]+face_size[j]+mouseY/200, 10/face_size[j]+face_size[j], 10/face_size[j]+face_size[j]);
// Used line for his eyebrow
line(720/face_size[j]+face_size[j], 370/face_size[j]+face_size[j], 770/face_size[j]+face_size[j], 385/face_size[j]+face_size[j]);
fill(255);
stroke(255);
ellipse(770/face_size[j]+face_size[j], 330/face_size[j]+face_size[j], 30/face_size[j]+face_size[j], 30/face_size[j]+face_size[j]);
ellipse(750/face_size[j]+face_size[j], 300/face_size[j]+face_size[j], 20/face_size[j]+face_size[j], 20/face_size[j]+face_size[j]);
	strokeWeight(8)
	stroke(mouseX%256,mouseY%256,100)}
		
	}
